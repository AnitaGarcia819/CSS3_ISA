#include <cstdlib>
#include <iostream>
#include "assembly_program.h"

using namespace std;
int main()
{
    // make a program object
    Program p1;

    // test for the "convert" function
    
    /*
    string names[] = {"c1","a2","d12","f327"};
    string expected[] = {"1","2","12","327"};

    for (int i = 0; i < 4; i++)
        cout << p1.convert(names[i]) << " -> " << expected[i] << endl;

    string names2[] = {"1","00002","567","23"};
    string expected2[] = {"1","2","567","23"};
    
    for (int i = 0; i < 4; i++)
        cout << p1.convert(names2[i]) << " -> " << expected2[i] << endl;

    cout << "well  done" << endl;*/

    // test for the "getu" function

    //p1.getu("r00", 0);
    

    return EXIT_SUCCESS;
}
